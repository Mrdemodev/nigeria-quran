package com.nigeriaquran.nigeria_quran

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
